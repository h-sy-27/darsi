create table if not exists profiles (
  user_id text primary key,
  display_name text not null default '',
  role text not null default 'student',
  grade text not null default 'عاشر',
  points integer not null default 0,
  streak integer not null default 0,
  last_study_date date,
  goal_percent integer not null default 0,
  weekly_minutes integer not null default 0,
  onboarded boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists subjects (
  id serial primary key,
  user_id text not null,
  name text not null,
  grade text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists subjects_user_id_idx on subjects (user_id);

create table if not exists materials (
  id serial primary key,
  user_id text not null,
  subject_id integer,
  title text not null,
  kind text not null default 'note',
  body text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists materials_user_id_idx on materials (user_id);

create table if not exists study_groups (
  id serial primary key,
  owner_id text not null,
  name text not null,
  subject text not null default '',
  join_code text not null unique,
  created_at timestamptz not null default now()
);
create index if not exists study_groups_owner_idx on study_groups (owner_id);

create table if not exists group_members (
  group_id integer not null,
  user_id text not null,
  member_role text not null default 'student',
  display_name text not null default '',
  joined_at timestamptz not null default now(),
  primary key (group_id, user_id)
);
create index if not exists group_members_user_idx on group_members (user_id);

create table if not exists group_posts (
  id serial primary key,
  group_id integer not null,
  user_id text not null,
  kind text not null default 'announcement',
  title text not null default '',
  body text not null,
  due_date date,
  created_at timestamptz not null default now()
);
create index if not exists group_posts_group_idx on group_posts (group_id);

create table if not exists flashcards (
  id serial primary key,
  user_id text not null,
  material_id integer,
  front text not null,
  back text not null,
  known boolean not null default false
);
create index if not exists flashcards_user_idx on flashcards (user_id);

create table if not exists quizzes (
  id serial primary key,
  user_id text not null,
  title text not null,
  questions jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists mistakes (
  id serial primary key,
  user_id text not null,
  subject text not null default '',
  question text not null,
  wrong text not null default '',
  correct text not null default '',
  created_at timestamptz not null default now()
);
create index if not exists mistakes_user_idx on mistakes (user_id);

create table if not exists tasks (
  id serial primary key,
  user_id text not null,
  title text not null,
  due_date date,
  done boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists tasks_user_idx on tasks (user_id);

create table if not exists habits (
  id serial primary key,
  user_id text not null,
  name text not null,
  done_today boolean not null default false,
  streak integer not null default 0
);

create table if not exists exam_dates (
  id serial primary key,
  user_id text not null,
  title text not null,
  exam_date date not null
);

create table if not exists ai_notes (
  id serial primary key,
  user_id text not null,
  tool text not null,
  title text not null,
  content text not null,
  created_at timestamptz not null default now()
);

create table if not exists dictionary_terms (
  id serial primary key,
  user_id text not null,
  term text not null,
  definition text not null,
  subject text not null default ''
);

create table if not exists week_slots (
  id serial primary key,
  user_id text not null,
  day integer not null,
  label text not null,
  minutes integer not null default 45
);

create table if not exists study_logs (
  id serial primary key,
  user_id text not null,
  minutes integer not null,
  day date not null default current_date
);
