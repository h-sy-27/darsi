import { useEffect, useMemo, useRef, useState } from "react";
import { Clock3, Lightbulb, Sparkles } from "lucide-react";
import {
  addExam,
  addHabit,
  addMistake,
  addTask,
  addTerm,
  addWeekSlot,
  logStudy,
  markFlash,
  runAi,
  runAiJson,
  speakSummary,
  toggleHabit,
  toggleTask,
} from "@/lib/server/darsi";
import { useDarsi } from "@/lib/darsi-store";
import type { ToolDef } from "@/lib/tools-catalog";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";

const DAYS = ["أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"];

export function ToolWorkspace({ tool }: { tool: ToolDef }) {
  const { data, reload } = useDarsi();
  const materialText = useMemo(
    () => data?.materials.map((m) => `## ${m.title}\n${m.body}`).join("\n\n") ?? "",
    [data],
  );

  return (
    <div className="space-y-5">
      <header className="tools-hero">
        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="eyebrow"><Sparkles className="size-4"/> {tool.group === "understand" ? "الفهم والشرح" : tool.group === "memory" ? "الحفظ والتثبيت" : tool.group === "exam" ? "الامتحانات والتقييم" : "أدوات دراسية"}</div>
            <h1 className="mt-2 text-3xl font-black">{tool.title}</h1>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-muted">{tool.blurb}</p>
          </div>
          <div className="hidden rounded-2xl bg-primary-soft p-4 text-primary sm:block"><Lightbulb className="size-5"/></div>
        </div>
      </header>
      {tool.mode === "ai" ? <AiPanel tool={tool} seed={materialText} /> : null}
      {tool.mode === "flash" ? <FlashPanel seed={materialText} /> : null}
      {tool.mode === "quiz" ? <QuizPanel seed={materialText} full={tool.id === "full-exam"} /> : null}
      {tool.mode === "cover" ? <CoverPanel /> : null}
      {tool.mode === "timer" ? <TimerPanel /> : null}
      {tool.mode === "tasks" ? <TasksPanel /> : null}
      {tool.mode === "habits" ? <HabitsPanel /> : null}
      {tool.mode === "exams" ? <ExamsPanel /> : null}
      {tool.mode === "week" ? <WeekPanel /> : null}
      {tool.mode === "calc" ? <CalcPanel /> : null}
      {tool.mode === "scan" ? <ScanPanel tool={tool} /> : null}
      {tool.mode === "mistakes" ? <MistakesPanel seed={materialText} /> : null}
      {tool.mode === "dict" ? <DictPanel /> : null}
      {tool.mode === "today" ? <TodayPanel /> : null}
    </div>
  );
}

function AiPanel({ tool, seed }: { tool: ToolDef; seed: string }) {
  const [input, setInput] = useState(seed.slice(0, 4000));
  const [out, setOut] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [audio, setAudio] = useState<string | null>(null);

  return (
    <div className="section-card space-y-4">
      <Textarea value={input} onChange={(e) => setInput(e.target.value)} placeholder="الصق الدرس أو السؤال" />
      <div className="flex flex-wrap gap-2">
        <Button
          disabled={busy || !input.trim()}
          onClick={async () => {
            setBusy(true);
            setErr(null);
            const r = await runAi({ data: { tool: tool.id, input } });
            if (r.ok) setOut(r.text);
            else setErr(r.error);
            setBusy(false);
          }}
        >
          {busy ? "يكتب…" : "توليد"}
        </Button>
        {tool.id === "audio-sum" && out ? (
          <Button
            variant="outline"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              const r = await speakSummary({ data: out.slice(0, 1100) });
              if (r.ok) setAudio(`data:audio/mpeg;base64,${r.audio}`);
              else setErr(r.error);
              setBusy(false);
            }}
          >
            استمع
          </Button>
        ) : null}
      </div>
      {err ? <p className="text-sm text-danger">{err}</p> : null}
      {audio ? <audio className="w-full" controls src={audio} /> : null}
      {out ? (
        <article className="whitespace-pre-wrap rounded-xl border border-border bg-surface p-4 text-sm leading-7">
          {out}
        </article>
      ) : null}
    </div>
  );
}

function FlashPanel({ seed }: { seed: string }) {
  const { data, reload } = useDarsi();
  const [input, setInput] = useState(seed.slice(0, 4000));
  const [i, setI] = useState(0);
  const [flip, setFlip] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const cards = data?.flash ?? [];
  const card = cards[i];

  return (
    <div className="section-card space-y-4">
      <Textarea value={input} onChange={(e) => setInput(e.target.value)} />
      <Button
        disabled={busy || !input.trim()}
        onClick={async () => {
          setBusy(true);
          const r = await runAiJson({ data: { kind: "flash", input } });
          if (!r.ok) setErr(r.error);
          reload();
          setBusy(false);
        }}
      >
        توليد بطاقات
      </Button>
      {err ? <p className="text-sm text-danger">{err}</p> : null}
      {card ? (
        <div>
          <button
            type="button"
            onClick={() => setFlip((f) => !f)}
            className="grid min-h-40 w-full place-items-center rounded-xl border border-border bg-surface p-6 text-center text-lg"
          >
            {flip ? card.back : card.front}
          </button>
          <div className="mt-3 flex gap-2">
            <Button
              variant="outline"
              onClick={async () => {
                await markFlash({ data: { id: card.id, known: false } });
                setFlip(false);
                setI((n) => (n + 1) % cards.length);
                reload();
              }}
            >
              أعدها
            </Button>
            <Button
              onClick={async () => {
                await markFlash({ data: { id: card.id, known: true } });
                setFlip(false);
                setI((n) => (n + 1) % cards.length);
                reload();
              }}
            >
              أعرفها
            </Button>
          </div>
          <p className="mt-2 text-xs text-muted">
            {i + 1} / {cards.length}
          </p>
        </div>
      ) : (
        <p className="text-sm text-muted">لا بطاقات بعد.</p>
      )}
    </div>
  );
}

function QuizPanel({ seed, full }: { seed: string; full: boolean }) {
  const [input, setInput] = useState(seed.slice(0, 4000));
  const [qs, setQs] = useState<{ q: string; options: string[]; answer: number; why?: string }[]>([]);
  const [pick, setPick] = useState<Record<number, number>>({});
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const score = qs.filter((q, i) => pick[i] === q.answer).length;

  return (
    <div className="section-card space-y-4">
      <Textarea value={input} onChange={(e) => setInput(e.target.value)} />
      <Button
        disabled={busy || !input.trim()}
        onClick={async () => {
          setBusy(true);
          setDone(false);
          setPick({});
          const r = await runAiJson({ data: { kind: "quiz", input, count: full ? 12 : 6 } });
          if (r.ok && "questions" in r && r.questions) setQs(r.questions);
          else if (!r.ok) setErr(r.error);
          setBusy(false);
        }}
      >
        ابدأ الاختبار
      </Button>
      {err ? <p className="text-sm text-danger">{err}</p> : null}
      {qs.map((q, i) => (
        <div key={i} className="rounded-xl border border-border bg-surface p-4">
          <p className="font-medium">
            {i + 1}. {q.q}
          </p>
          <div className="mt-2 space-y-1">
            {q.options.map((o, j) => (
              <button
                key={j}
                type="button"
                disabled={done}
                onClick={() => setPick((p) => ({ ...p, [i]: j }))}
                className={`block w-full rounded-md border px-3 py-2 text-right text-sm ${
                  pick[i] === j ? "border-primary bg-primary-soft" : "border-border"
                }`}
              >
                {o}
              </button>
            ))}
          </div>
          {done ? (
            <p className="mt-2 text-sm text-muted">
              الصحيح: {q.options[q.answer]} {q.why ? `— ${q.why}` : ""}
            </p>
          ) : null}
        </div>
      ))}
      {qs.length ? (
        <Button onClick={() => setDone(true)}>تسليم</Button>
      ) : null}
      {done ? <p className="font-semibold tabular-nums">النتيجة {score} / {qs.length}</p> : null}
    </div>
  );
}

function CoverPanel() {
  const { data } = useDarsi();
  const [hide, setHide] = useState(true);
  const cards = data?.flash ?? [];
  const [i, setI] = useState(0);
  const c = cards[i];
  if (!c) return <p className="text-sm text-muted">ولّد فلاش كاردز أولاً.</p>;
  return (
    <div className="section-card space-y-4">
      <div className="rounded-2xl border border-border bg-bg p-6">
        <p className="font-medium">{c.front}</p>
        <p className={`mt-3 text-sm ${hide ? "select-none blur-sm" : ""}`}>{c.back}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant="outline" onClick={() => setHide((h) => !h)}>
          {hide ? "كشف" : "غطّي"}
        </Button>
        <Button
          onClick={() => {
            setHide(true);
            setI((n) => (n + 1) % cards.length);
          }}
        >
          التالية
        </Button>
      </div>
    </div>
  );
}

function TimerPanel() {
  const { reload } = useDarsi();
  const [secs, setSecs] = useState(25 * 60);
  const [run, setRun] = useState(false);
  const startedAt = useRef<number | null>(null);
  const interval = useRef<number | null>(null);
  useEffect(() => () => { if (interval.current) window.clearInterval(interval.current); }, []);
  async function finish(record = true) {
    if (interval.current) window.clearInterval(interval.current);
    interval.current = null; setRun(false);
    const studied = Math.floor((25 * 60 - secs) / 60);
    if (record && studied > 0) { await logStudy({ data: studied }); await reload(); }
  }
  function start() {
    if (run) return;
    startedAt.current = Date.now(); setRun(true);
    interval.current = window.setInterval(() => setSecs(s => Math.max(0, s - 1)), 1000);
  }
  useEffect(() => { if (secs === 0 && run) void finish(true); }, [secs, run]);
  const m=Math.floor(secs/60), s=secs%60, progress=((25*60-secs)/(25*60))*100;
  return <div className="section-card p-7 text-center">
    <div className="mx-auto grid size-24 place-items-center rounded-[28px] bg-primary-soft text-primary"><Clock3 className="size-8"/></div>
    <div className="mt-5 text-6xl font-black tabular-nums tracking-tight">{String(m).padStart(2,"0")}:{String(s).padStart(2,"0")}</div>
    <p className="mt-2 text-sm text-muted">جلسة تركيز 25 دقيقة · أغلق المشتتات وابدأ.</p>
    <div className="mx-auto mt-5 h-2 max-w-sm overflow-hidden rounded-full bg-bg"><div className="h-full rounded-full bg-primary transition-all" style={{width:`${progress}%`}}/></div>
    <div className="mt-5 flex justify-center gap-2">
      <Button onClick={start} disabled={run}>{run?"جلسة جارية":"ابدأ التركيز"}</Button>
      <Button variant="outline" onClick={()=>void finish(true)} disabled={!run}>أوقف وسجّل</Button>
      <Button variant="ghost" onClick={()=>{if(interval.current)window.clearInterval(interval.current);interval.current=null;setRun(false);setSecs(25*60)}}>تصفير</Button>
    </div>
    {startedAt.current ? <p className="mt-4 text-[10px] text-subtle">تُسجّل الدقائق عند الإيقاف أو انتهاء الجلسة.</p>:null}
  </div>;
}

function TasksPanel() {
  const { data, reload } = useDarsi();
  const [title, setTitle] = useState("");
  return (
    <div className="section-card space-y-4">
      <form
        className="flex flex-wrap gap-2"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!title.trim()) return;
          await addTask({ data: { title: title.trim() } });
          setTitle("");
          reload();
        }}
      >
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مهمة جديدة" />
        <Button>إضافة</Button>
      </form>
      <ul className="space-y-2">
        {(data?.tasks ?? []).map((t) => (
          <li key={t.id} className="flex items-center justify-between rounded-lg border border-border bg-surface px-3 py-2">
            <span className={t.done ? "text-muted line-through" : ""}>{t.title}</span>
            <Button size="sm" variant="ghost" onClick={async () => { await toggleTask({ data: t.id }); reload(); }}>
              {t.done ? "تراجع" : "تم"}
            </Button>
          </li>
        ))}
      </ul>
    </div>
  );
}

function HabitsPanel() {
  const { data, reload } = useDarsi();
  const [name, setName] = useState("");
  return (
    <div className="section-card space-y-4">
      <form
        className="flex flex-wrap gap-2"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!name.trim()) return;
          await addHabit({ data: name.trim() });
          setName("");
          reload();
        }}
      >
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="عادة يومية" />
        <Button>إضافة</Button>
      </form>
      {(data?.habits ?? []).map((h) => (
        <button
          key={h.id}
          type="button"
          onClick={async () => {
            await toggleHabit({ data: h.id });
            reload();
          }}
          className="flex w-full items-center justify-between rounded-lg border border-border bg-surface px-4 py-3 text-sm"
        >
          <span>{h.name}</span>
          <span className="tabular-nums text-muted">
            {h.done_today ? "اليوم" : "لم تُنجز"} · سلسلة {h.streak}
          </span>
        </button>
      ))}
    </div>
  );
}

function ExamsPanel() {
  const { data, reload } = useDarsi();
  const [title, setTitle] = useState("");
  const [date, setDate] = useState("");
  return (
    <div className="section-card space-y-4">
      <form
        className="grid gap-2 sm:grid-cols-[1fr_auto_auto]"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!title || !date) return;
          await addExam({ data: { title, exam_date: date } });
          setTitle("");
          reload();
        }}
      >
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="اسم الامتحان" />
        <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
        <Button>حفظ</Button>
      </form>
      <ul className="space-y-2">
        {(data?.exams ?? []).map((e) => {
          const days = Math.ceil((new Date(e.exam_date).getTime() - Date.now()) / 86400000);
          return (
            <li key={e.id} className="flex justify-between rounded-lg border border-border bg-surface px-4 py-3 text-sm">
              <span>{e.title}</span>
              <span className="tabular-nums text-muted">{days >= 0 ? `${days} يوم` : "انتهى"}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function WeekPanel() {
  const { data, reload } = useDarsi();
  const [day, setDay] = useState(0);
  const [label, setLabel] = useState("");
  const [minutes, setMinutes] = useState(45);
  return (
    <div className="section-card space-y-4">
      <form
        className="grid gap-2 sm:grid-cols-4"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!label.trim()) return;
          await addWeekSlot({ data: { day, label: label.trim(), minutes } });
          setLabel("");
          reload();
        }}
      >
        <select className="h-11 rounded-md border border-border bg-surface px-3 text-sm" value={day} onChange={(e) => setDay(Number(e.target.value))}>
          {DAYS.map((d, i) => (
            <option key={d} value={i}>
              {d}
            </option>
          ))}
        </select>
        <Input value={label} onChange={(e) => setLabel(e.target.value)} placeholder="المادة / النشاط" />
        <Input type="number" value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} />
        <Button>توزيع</Button>
      </form>
      <div className="grid gap-2 sm:grid-cols-2">
        {DAYS.map((d, i) => (
          <div key={d} className="rounded-lg border border-border bg-surface p-3">
            <div className="text-xs text-muted">{d}</div>
            <ul className="mt-1 text-sm">
              {(data?.week ?? [])
                .filter((s) => s.day === i)
                .map((s) => (
                  <li key={s.id}>
                    {s.label} · {s.minutes} د
                  </li>
                ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

function CalcPanel() {
  const [v, setV] = useState("0");
  function press(ch: string) {
    if (ch === "C") return setV("0");
    if (ch === "=") {
      try {
        const safe = v.replace(/[^0-9+\-*/().% ]/g, "");
        // eslint-disable-next-line no-new-func
        const r = Function(`"use strict"; return (${safe})`)();
        setV(String(r));
      } catch {
        setV("خطأ");
      }
      return;
    }
    setV((s) => (s === "0" || s === "خطأ" ? ch : s + ch));
  }
  const keys = ["7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "C", "+", "="];
  return (
    <div className="mx-auto max-w-xs rounded-xl border border-border bg-surface p-4">
      <div className="mb-3 rounded-md border border-border bg-bg px-3 py-4 text-left text-2xl tabular-nums">{v}</div>
      <div className="grid grid-cols-4 gap-2">
        {keys.map((k) => (
          <Button key={k} variant={k === "=" ? "default" : "outline"} onClick={() => press(k)}>
            {k}
          </Button>
        ))}
      </div>
    </div>
  );
}

function ScanPanel({ tool }: { tool: ToolDef }) {
  const [note, setNote] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  return (
    <div className="section-card space-y-4">
      <p className="text-sm text-muted">التقط صورة الصفحة ثم اكتب ما تقرأه أو الصق النص المستخرج ليُشرح.</p>
      <input
        type="file"
        accept="image/*"
        capture="environment"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (!f) return;
          setPreview(URL.createObjectURL(f));
        }}
      />
      {preview ? <img src={preview} alt="مسح" className="max-h-64 rounded-lg border border-border" /> : null}
      <AiPanel tool={tool} seed={note} />
      <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="وصف سريع للصورة إن رغبت" />
    </div>
  );
}

function MistakesPanel({ seed }: { seed: string }) {
  const { data, reload } = useDarsi();
  const [q, setQ] = useState("");
  const [wrong, setWrong] = useState("");
  const [correct, setCorrect] = useState("");
  const [busy, setBusy] = useState(false);
  const [out, setOut] = useState("");
  return (
    <div className="section-card space-y-4">
      <form
        className="space-y-2 rounded-xl border border-border bg-surface p-4"
        onSubmit={async (e) => {
          e.preventDefault();
          await addMistake({ data: { subject: "", question: q, wrong, correct } });
          setQ("");
          setWrong("");
          setCorrect("");
          reload();
        }}
      >
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="السؤال الذي أخطأت فيه" />
        <Input value={wrong} onChange={(e) => setWrong(e.target.value)} placeholder="إجابتك الخاطئة" />
        <Input value={correct} onChange={(e) => setCorrect(e.target.value)} placeholder="الإجابة الصحيحة" />
        <Button>حفظ في الدفتر</Button>
      </form>
      <Button
        variant="secondary"
        disabled={busy}
        onClick={async () => {
          setBusy(true);
          const blob = (data?.mistakes ?? []).map((m) => `${m.question} | خطأ: ${m.wrong} | صح: ${m.correct}`).join("\n");
          const r = await runAi({
            data: {
              tool: "expected",
              input: `ابنِ اختباراً يركز على أخطاء الطالب التالية:\n${blob}\nالمادة:\n${seed.slice(0, 2000)}`,
            },
          });
          if (r.ok) setOut(r.text);
          setBusy(false);
        }}
      >
        اختبار من أخطائي
      </Button>
      <ul className="space-y-2 text-sm">
        {(data?.mistakes ?? []).map((m) => (
          <li key={m.id} className="rounded-lg border border-border bg-surface p-3">
            <div className="font-medium">{m.question}</div>
            <div className="text-danger">خطأ: {m.wrong}</div>
            <div className="text-ok">صح: {m.correct}</div>
          </li>
        ))}
      </ul>
      {out ? <article className="whitespace-pre-wrap rounded-xl border border-border p-4 text-sm">{out}</article> : null}
    </div>
  );
}

function DictPanel() {
  const { data, reload } = useDarsi();
  const [term, setTerm] = useState("");
  const [definition, setDefinition] = useState("");
  return (
    <div className="section-card space-y-4">
      <form
        className="space-y-2"
        onSubmit={async (e) => {
          e.preventDefault();
          await addTerm({ data: { term, definition, subject: "" } });
          setTerm("");
          setDefinition("");
          reload();
        }}
      >
        <Input value={term} onChange={(e) => setTerm(e.target.value)} placeholder="المصطلح" />
        <Textarea value={definition} onChange={(e) => setDefinition(e.target.value)} placeholder="التعريف" />
        <Button>حفظ</Button>
      </form>
      <ul className="space-y-2">
        {(data?.dict ?? []).map((t) => (
          <li key={t.id} className="rounded-lg border border-border bg-surface p-3">
            <div className="font-medium">{t.term}</div>
            <p className="text-sm text-muted">{t.definition}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

function TodayPanel() {
  const { data } = useDarsi();
  const day = new Date().getDay();
  const slots = (data?.week ?? []).filter((s) => s.day === day);
  const exams = data?.exams ?? [];
  return (
    <div className="section-card space-y-4">
      <div className="rounded-xl border border-border bg-surface p-4">
        <h2 className="font-medium">جدول اليوم</h2>
        {slots.length === 0 ? <p className="mt-2 text-sm text-muted">لا توزيع لهذا اليوم بعد.</p> : null}
        <ul className="mt-2 space-y-1 text-sm">
          {slots.map((s) => (
            <li key={s.id}>
              {s.label} — {s.minutes} دقيقة
            </li>
          ))}
        </ul>
      </div>
      <div className="rounded-xl border border-border bg-surface p-4">
        <h2 className="font-medium">أقرب الامتحانات</h2>
        <ul className="mt-2 text-sm">
          {exams.slice(0, 3).map((e) => (
            <li key={e.id}>
              {e.title} · {e.exam_date}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
