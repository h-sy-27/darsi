import { useMemo, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Bell, BookOpen, Brain, Command, Home, LayoutGrid, Search, Sparkles, UserRound, Users, X } from "lucide-react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/cn";
import { useDarsi } from "@/lib/darsi-store";
import { TOOLS } from "@/lib/tools-catalog";

const NAV = [
  { to: "/home", label: "الرئيسية", icon: Home },
  { to: "/library", label: "مكتبتي", icon: BookOpen },
  { to: "/tools", label: "الذكاء والأدوات", icon: Brain },
  { to: "/community", label: "المجتمع", icon: Users },
  { to: "/me", label: "حسابي", icon: UserRound },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const user = useCurrentUser();
  const { data, error } = useDarsi();
  const p = data?.profile;
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return TOOLS.slice(0, 6);
    return TOOLS.filter((t) => `${t.title} ${t.blurb}`.toLowerCase().includes(q)).slice(0, 8);
  }, [query]);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <header className="sticky top-0 z-40 border-b border-border/80 bg-white/90 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 lg:px-6">
          <Link to="/home" className="flex shrink-0 items-center gap-2.5">
            <span className="brand-mark">د</span>
            <div className="hidden sm:block">
              <div className="font-bold tracking-tight">درسي</div>
              <div className="text-[10px] text-muted">تعلّم أذكى، كل يوم</div>
            </div>
          </Link>

          <nav className="hidden flex-1 items-center justify-center gap-1 md:flex">
            {NAV.map((n) => {
              const Icon = n.icon;
              const active = path === n.to || path.startsWith(`${n.to}/`);
              return <Link key={n.to} to={n.to} className={cn("nav-pill", active && "nav-pill-active")}><Icon className="size-4" />{n.label}</Link>;
            })}
          </nav>

          <div className="mr-auto flex items-center gap-2">
            <button aria-label="بحث" onClick={() => setSearchOpen(true)} className="icon-btn hidden sm:grid"><Search className="size-4" /><span className="sr-only">بحث</span></button>
            <Link to="/tools/$id" params={{ id: "explain" }} className="quick-ai hidden items-center gap-2 rounded-xl px-3 py-2 text-xs font-bold sm:flex"><Sparkles className="size-3.5" />اسأل الذكاء</Link>
            <button aria-label="الإشعارات" className="icon-btn hidden sm:grid"><Bell className="size-4" /></button>
            {p ? <div className="hidden border-r border-border pr-3 text-right lg:block"><div className="text-xs font-bold">{p.points} نقطة</div><div className="text-[10px] text-muted">🔥 {p.streak} يوم متواصل</div></div> : null}
            <UserButton />
          </div>
        </div>
      </header>

      {error ? <div className="mx-auto max-w-7xl px-4 pt-4 lg:px-6"><div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-danger">تعذر تحميل بعض بيانات حسابك. جرّب تحديث الصفحة.</div></div> : null}
      <main className="mx-auto max-w-7xl px-4 pb-24 pt-6 lg:px-6 md:pb-10">{children}</main>

      <nav className="mobile-nav fixed inset-x-0 bottom-0 z-40 border-t border-border bg-white/95 backdrop-blur-xl md:hidden">
        <div className="grid grid-cols-5 px-1 pb-[env(safe-area-inset-bottom)]">
          {NAV.map((n) => { const Icon=n.icon; const on=path===n.to || path.startsWith(`${n.to}/`); return <Link key={n.to} to={n.to} className={cn("flex min-h-16 flex-col items-center justify-center gap-1 text-[10px] font-medium", on ? "text-primary" : "text-muted")}><span className={cn("grid size-8 place-items-center rounded-xl", on && "bg-primary-soft")}><Icon className="size-4" /></span>{n.label}</Link>; })}
        </div>
      </nav>

      {searchOpen ? (
        <div className="fixed inset-0 z-50 bg-slate-950/30 p-4 backdrop-blur-sm" onMouseDown={() => setSearchOpen(false)}>
          <div className="mx-auto mt-[8vh] w-full max-w-2xl overflow-hidden rounded-[28px] border border-border bg-white shadow-2xl" onMouseDown={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 border-b border-border p-4"><Search className="size-5 text-primary" /><input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث عن أداة أو طريقة للمذاكرة…" className="min-w-0 flex-1 bg-transparent text-sm outline-none" /><kbd className="hidden rounded-lg bg-bg px-2 py-1 text-[10px] text-muted sm:block">ESC</kbd><button onClick={() => setSearchOpen(false)} className="icon-btn"><X className="size-4" /></button></div>
            <div className="p-3"><div className="px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-subtle">اقتراحات</div>{matches.map((t) => <Link key={t.id} to="/tools/$id" params={{id:t.id}} onClick={() => setSearchOpen(false)} className="flex items-center gap-3 rounded-2xl p-3 hover:bg-bg"><span className="grid size-10 place-items-center rounded-xl bg-primary-soft text-primary"><Command className="size-4" /></span><span className="min-w-0"><b className="block text-sm">{t.title}</b><span className="block truncate text-xs text-muted">{t.blurb}</span></span></Link>)}</div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
