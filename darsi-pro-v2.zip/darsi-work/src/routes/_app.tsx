import { createFileRoute, Outlet } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { DarsiProvider } from "@/lib/darsi-store";
import { Shell } from "@/components/shell";
import { Onboard } from "@/components/onboard";

export const Route = createFileRoute("/_app")({ component: AppLayout });

function AppLayout() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <div className="grid min-h-dvh place-items-center bg-bg">
        <div className="h-24 w-56 animate-pulse rounded-xl bg-border" />
      </div>
    );
  }
  if (!user) return <RedirectToSignIn />;
  return (
    <DarsiProvider enabled>
      <Shell>
        <Onboard />
        <Outlet />
      </Shell>
    </DarsiProvider>
  );
}
