import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, BookOpen, Brain, CalendarDays, CheckCircle2, Clock3, Flame, NotebookPen, Plus, Sparkles, Target, Trophy, Zap } from "lucide-react";
import { useDarsi } from "@/lib/darsi-store";

export const Route = createFileRoute("/_app/home")({ component: Home });
const DAYS = ["أحد", "إثنين", "ثلاثاء", "أربعاء", "خميس", "جمعة", "سبت"];

function Home() {
  const { data, loading } = useDarsi();
  if (loading || !data) return <div className="space-y-4"><div className="h-52 animate-pulse rounded-[30px] bg-border"/><div className="grid gap-3 sm:grid-cols-4">{[1,2,3,4].map(i=><div key={i} className="h-28 animate-pulse rounded-2xl bg-border"/>)}</div></div>;
  const p=data.profile;
  const byDay=Array.from({length:7},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(6-i));const key=d.toISOString().slice(0,10);const mins=data.logs.filter(l=>String(l.day).slice(0,10)===key).reduce((a,b)=>a+b.minutes,0);return {label:DAYS[d.getDay()],mins};});
  const max=Math.max(30,...byDay.map(d=>d.mins));
  const open=data.tasks.filter(t=>!t.done).slice(0,4);
  const upcoming=data.exams.filter(e=>new Date(e.exam_date).getTime()>=Date.now()).slice(0,3);
  const subjectCount=data.subjects.length;
  return <div className="space-y-6">
    <section className="hero-dashboard">
      <div className="hero-orb hero-orb-a"/><div className="hero-orb hero-orb-b"/>
      <div className="relative grid gap-7 lg:grid-cols-[1fr_330px] lg:items-center">
        <div><div className="eyebrow-dark"><Sparkles className="size-4"/> لوحة تقدّمك اليوم</div><h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">أهلاً {p.display_name || "بك"} 👋</h1><p className="mt-3 max-w-xl text-sm leading-7 text-white/70">جلسة واحدة مركّزة اليوم أفضل من خطة ضخمة لا تبدأ بها. اختر مهمة وأنجزها الآن.</p><div className="mt-6 flex flex-wrap gap-2"><Link to="/tools/$id" params={{id:"today"}} className="primary-light-btn">ابدأ خطة اليوم <ArrowLeft className="mr-2 size-4"/></Link><Link to="/tools/$id" params={{id:"timer"}} className="ghost-light-btn"><Clock3 className="ml-2 size-4"/> جلسة تركيز</Link></div></div>
        <div className="glass-stat"><div className="flex items-center justify-between text-sm"><span>إنجاز هدف اليوم</span><b>{p.goal_percent}%</b></div><div className="mt-4 h-3 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-white transition-all" style={{width:`${p.goal_percent}%`}}/></div><div className="mt-3 flex items-center justify-between text-xs text-white/55"><span>{Math.max(0,100-p.goal_percent)}% متبقية</span><span>🔥 {p.streak} يوم متواصل</span></div><div className="mt-5 grid grid-cols-2 gap-2"><div className="rounded-xl bg-white/8 p-3"><div className="text-[10px] text-white/50">موادك</div><div className="mt-1 font-bold">{subjectCount}</div></div><div className="rounded-xl bg-white/8 p-3"><div className="text-[10px] text-white/50">مهام مفتوحة</div><div className="mt-1 font-bold">{open.length}</div></div></div></div>
      </div>
    </section>

    <section className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><Metric icon={Trophy} label="النقاط" value={String(p.points)} hint="مستواك يتقدم"/><Metric icon={Flame} label="السلسلة" value={`${p.streak} يوم`} hint="حافظ عليها"/><Metric icon={Clock3} label="هذا الأسبوع" value={`${p.weekly_minutes} د`} hint="وقت الدراسة"/><Metric icon={Target} label="هدف اليوم" value={`${p.goal_percent}%`} hint="نسبة الإنجاز"/></section>

    <section className="grid gap-5 lg:grid-cols-[1.25fr_.75fr]">
      <div className="section-card"><div className="section-head"><div><h2>ماذا تريد أن تنجز؟</h2><p>أقصر طريق من الشاشة إلى الفعل.</p></div><Zap className="size-5 text-primary"/></div><div className="mt-4 grid gap-3 sm:grid-cols-2">{[[NotebookPen,"لخّص درساً","حوّل المادة إلى نقاط مراجعة","summarize"],[Brain,"اشرح لي","فكّك أصعب فكرة عندك","explain"],[BookOpen,"مكتبتي","راجع ما حفظته وأضف مادة","library"],[CalendarDays,"رتّب أسبوعك","وزّع وقتك بدون ضغط","schedule"]].map(([I,t,s,id])=>{const Icon=I as typeof BookOpen;return id==="library" ? <Link key={String(t)} to="/library" className="action-card"><span className="action-icon"><Icon className="size-5"/></span><span className="min-w-0"><b>{t}</b><small>{s}</small></span><ArrowLeft className="mr-auto size-4 text-subtle"/></Link> : <Link key={String(t)} to="/tools/$id" params={{id:String(id)}} className="action-card"><span className="action-icon"><Icon className="size-5"/></span><span className="min-w-0"><b>{t}</b><small>{s}</small></span><ArrowLeft className="mr-auto size-4 text-subtle"/></Link>})}</div></div>
      <div className="section-card"><div className="section-head"><div><h2>نشاطك</h2><p>آخر 7 أيام</p></div><span className="mini-chip">دقائق</span></div><div className="mt-5 flex h-44 items-end gap-2">{byDay.map(d=><div key={d.label} className="flex h-full flex-1 flex-col items-center justify-end gap-2"><div className="bar-track"><div className="bar-fill" style={{height:`${Math.max(7,(d.mins/max)*100)}%`}}/></div><span className="text-[10px] text-muted">{d.label}</span></div>)}</div></div>
    </section>

    <section className="grid gap-5 lg:grid-cols-[1fr_.75fr]">
      <div className="section-card"><div className="section-head"><div><h2>مهامك المفتوحة</h2><p>أنجز الأصغر أولاً لتحافظ على الزخم.</p></div><Link to="/tools/$id" params={{id:"tasks"}} className="text-xs font-bold text-primary">كل المهام <ArrowLeft className="mr-1 inline size-3.5"/></Link></div>{open.length?<div className="mt-4 space-y-2">{open.map(t=><div key={t.id} className="task-row"><span className="grid size-9 place-items-center rounded-xl bg-primary-soft text-primary"><CheckCircle2 className="size-4"/></span><span className="min-w-0 flex-1"><b className="block truncate text-sm">{t.title}</b><small>{t.due_date?`موعد التسليم ${t.due_date}`:"بدون موعد"}</small></span><ArrowLeft className="size-4 text-subtle"/></div>)}</div>:<div className="empty-state"><Plus className="mx-auto mb-2 size-5"/>لا توجد مهام معلّقة حالياً.</div>}</div>
      <div className="section-card"><div className="section-head"><div><h2>الامتحانات القادمة</h2><p>لا تتركها لآخر ليلة.</p></div><Link to="/tools/$id" params={{id:"countdown"}} className="text-xs font-bold text-primary">العدّاد</Link></div>{upcoming.length?<div className="mt-4 space-y-2">{upcoming.map(e=>{const days=Math.max(0,Math.ceil((new Date(e.exam_date).getTime()-Date.now())/86400000));return <div key={e.id} className="exam-row"><span className="grid size-10 place-items-center rounded-xl bg-bg text-primary"><CalendarDays className="size-4"/></span><span className="min-w-0 flex-1"><b className="block truncate text-sm">{e.title}</b><small>{e.exam_date}</small></span><strong>{days} <small>يوم</small></strong></div>})}</div>:<div className="empty-state">أضف أول امتحان من عدّاد الامتحانات.</div>}</div>
    </section>
  </div>;
}
function Metric({icon:Icon,label,value,hint}:{icon:typeof Trophy;label:string;value:string;hint:string}){return <div className="metric-card"><div className="flex items-center justify-between"><span className="metric-icon"><Icon className="size-4"/></span><span className="text-[10px] text-muted">{hint}</span></div><div className="mt-4 text-xs text-muted">{label}</div><div className="mt-1 text-2xl font-bold tabular-nums">{value}</div></div>}
