import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Brain, Calculator, Camera, ClipboardCheck, Clock3, FileText, Flame, Lightbulb, ListChecks, Mic, Search, Sparkles, Target } from "lucide-react";
import { useMemo, useState } from "react";
import { GROUPS, TOOLS } from "@/lib/tools-catalog";

export const Route = createFileRoute("/_app/tools")({ component: Tools });
const ICONS=[Brain,FileText,Camera,Sparkles,Lightbulb,Target,ClipboardCheck,Mic,ListChecks,Clock3,Calculator,Flame];
const POPULAR=["explain","summarize","quiz","flashcards","timer","mistake-book"];
function Tools(){
  const [q,setQ]=useState("");
  const filtered=useMemo(()=>{const s=q.trim().toLowerCase();return s?TOOLS.filter(t=>`${t.title} ${t.blurb}`.toLowerCase().includes(s)):TOOLS;},[q]);
  return <div className="space-y-7">
    <header className="tools-hero"><div className="hero-grid"/><div className="relative"><div className="eyebrow"><Sparkles className="size-4"/> مركز الذكاء الدراسي</div><h1 className="mt-3 text-3xl font-bold sm:text-4xl">كل أدواتك الدراسية في مكان واحد.</h1><p className="mt-3 max-w-2xl text-sm leading-7 text-muted">شرح، تلخيص، اختبارات، فلاش كاردز، تنظيم وقياس تقدّم. اختر الهدف أولاً، ثم الأداة.</p><div className="relative mt-6 max-w-2xl"><Search className="absolute right-4 top-1/2 size-5 -translate-y-1/2 text-subtle"/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="ابحث: شرح، اختبار، حفظ، وقت…" className="h-13 w-full rounded-2xl border border-border bg-white pr-12 pl-4 text-sm shadow-sm outline-none transition focus:border-primary focus:ring-4 focus:ring-primary/10"/></div></div></header>
    {!q && <section><div className="section-head mb-3"><div><h2>الأكثر استخداماً</h2><p>ابدأ من الأدوات التي تعطيك نتيجة مباشرة.</p></div></div><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{POPULAR.map((id,i)=>{const t=TOOLS.find(x=>x.id===id)!;const Icon=ICONS[i%ICONS.length];return <Link key={id} to="/tools/$id" params={{id}} className="featured-tool"><span className="grid size-11 place-items-center rounded-2xl bg-primary-soft text-primary"><Icon className="size-5"/></span><span className="min-w-0 flex-1"><b>{t.title}</b><small>{t.blurb}</small></span><ArrowLeft className="size-4 text-subtle"/></Link>})}</div></section>}
    {q ? <section><div className="section-head mb-3"><div><h2>نتائج البحث</h2><p>{filtered.length} أداة مطابقة.</p></div></div><ToolGrid tools={filtered}/></section> : GROUPS.map(g=>{const tools=TOOLS.filter(t=>t.group===g.id);return <section key={g.id}><div className="section-head mb-3"><div><h2>{g.title}</h2><p>أدوات مختارة لهذه المرحلة.</p></div><span className="mini-chip">{tools.length} أدوات</span></div><ToolGrid tools={tools}/></section>})}
  </div>
}
function ToolGrid({tools}:{tools:typeof TOOLS}){return <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{tools.map((t,i)=>{const Icon=ICONS[(i+t.id.length)%ICONS.length];return <Link key={t.id} to="/tools/$id" params={{id:t.id}} className="tool-card"><div className="flex items-start justify-between"><span className="tool-icon"><Icon className="size-5"/></span><ArrowLeft className="size-4 text-subtle transition group-hover:-translate-x-1"/></div><div className="mt-4 font-bold">{t.title}</div><p className="mt-1 text-sm leading-6 text-muted">{t.blurb}</p></Link>})}</div>}
