import { createFileRoute } from "@tanstack/react-router";
import { ToolWorkspace } from "@/components/tool-workspace";
import { toolById } from "@/lib/tools-catalog";

export const Route = createFileRoute("/_app/tools/$id")({ component: ToolPage });

function ToolPage() {
  const { id } = Route.useParams();
  const tool = toolById(id);
  if (!tool) return <p className="text-muted">الأداة غير موجودة.</p>;
  return <ToolWorkspace tool={tool} />;
}
