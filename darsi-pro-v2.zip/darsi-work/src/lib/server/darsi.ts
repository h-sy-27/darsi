import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import type { DarsiBoot, Profile, QuizQ } from "@/lib/darsi-types";
import { z } from "zod";

const str = z.string();

async function ensureProfile(userId: string, name: string) {
  const sql = await getSql();
  const rows = await sql<Profile>`select * from profiles where user_id = ${userId}`;
  if (rows[0]) return rows[0];
  await sql`insert into profiles (user_id, display_name) values (${userId}, ${name})`;
  const created = await sql<Profile>`select * from profiles where user_id = ${userId}`;
  return created[0];
}

export const getBootstrap = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<DarsiBoot> => {
    const sql = await getSql();
    const profile = await ensureProfile(context.userId, "طالب");
    const subjects = await sql<{ id: number; name: string; grade: string }>`
      select id, name, grade from subjects where user_id = ${context.userId} order by id desc`;
    const materials = await sql<{
      id: number; subject_id: number | null; title: string; kind: string; body: string;
    }>`select id, subject_id, title, kind, body from materials where user_id = ${context.userId} order by id desc`;
    const tasks = await sql<{ id: number; title: string; due_date: string | null; done: boolean }>`
      select id, title, due_date, done from tasks where user_id = ${context.userId} order by done, id desc`;
    const habits = await sql<{ id: number; name: string; done_today: boolean; streak: number }>`
      select id, name, done_today, streak from habits where user_id = ${context.userId} order by id`;
    const exams = await sql<{ id: number; title: string; exam_date: string }>`
      select id, title, exam_date from exam_dates where user_id = ${context.userId} order by exam_date`;
    const week = await sql<{ id: number; day: number; label: string; minutes: number }>`
      select id, day, label, minutes from week_slots where user_id = ${context.userId} order by day, id`;
    const mistakes = await sql<{ id: number; subject: string; question: string; wrong: string; correct: string }>`
      select id, subject, question, wrong, correct from mistakes where user_id = ${context.userId} order by id desc`;
    const flash = await sql<{ id: number; front: string; back: string; known: boolean }>`
      select id, front, back, known from flashcards where user_id = ${context.userId} order by id desc`;
    const dict = await sql<{ id: number; term: string; definition: string; subject: string }>`
      select id, term, definition, subject from dictionary_terms where user_id = ${context.userId} order by id desc`;
    const notes = await sql<{ id: number; tool: string; title: string; content: string }>`
      select id, tool, title, content from ai_notes where user_id = ${context.userId} order by id desc limit 20`;
    const quizRows = await sql<{ id: number; title: string; questions: QuizQ[] | string }>`
      select id, title, questions from quizzes where user_id = ${context.userId} order by id desc limit 8`;
    const quizzes = quizRows.map((q) => ({
      id: q.id,
      title: q.title,
      questions: (typeof q.questions === "string" ? JSON.parse(q.questions) : q.questions) as QuizQ[],
    }));
    const groups = await sql<{
      id: number; name: string; subject: string; join_code: string; owner_id: string; member_role: string;
    }>`select g.id, g.name, g.subject, g.join_code, g.owner_id, m.member_role
       from group_members m join study_groups g on g.id = m.group_id
       where m.user_id = ${context.userId} order by g.id desc`;
    const logs = await sql<{ minutes: number; day: string }>`
      select minutes, day from study_logs where user_id = ${context.userId}
      and day >= (current_date - interval '6 days') order by day`;
    return {
      profile,
      subjects,
      materials,
      tasks,
      habits,
      exams,
      week,
      mistakes,
      flash,
      dict,
      notes,
      quizzes,
      groups,
      logs,
    };
  });

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (d: { display_name: string; role: string; grade: string }) =>
      z.object({
        display_name: str.min(1).max(80),
        role: z.enum(["student", "teacher"]),
        grade: str.max(40),
      }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(context.userId, data.display_name);
    await sql`update profiles set display_name = ${data.display_name}, role = ${data.role},
      grade = ${data.grade}, onboarded = true where user_id = ${context.userId}`;
    return { ok: true };
  });

export const addSubject = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { name: string; grade: string }) =>
    z.object({ name: str.min(1).max(80), grade: str.max(40) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: number }>`
      insert into subjects (user_id, name, grade) values (${context.userId}, ${data.name}, ${data.grade})
      returning id`;
    return rows[0];
  });

export const addMaterial = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { title: string; body: string; kind: string; subject_id?: number | null }) =>
    z.object({
      title: str.min(1).max(160),
      body: str.max(20000),
      kind: str.max(20),
      subject_id: z.number().nullable().optional(),
    }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: number }>`
      insert into materials (user_id, subject_id, title, kind, body)
      values (${context.userId}, ${data.subject_id ?? null}, ${data.title}, ${data.kind}, ${data.body})
      returning id`;
    await bumpPoints(context.userId, 8);
    return rows[0];
  });

export const addTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { title: string; due_date?: string | null }) =>
    z.object({ title: str.min(1).max(160), due_date: z.string().nullable().optional() }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into tasks (user_id, title, due_date) values (${context.userId}, ${data.title}, ${data.due_date ?? null})`;
    return { ok: true };
  });

export const toggleTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => z.number().parse(id))
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    await sql`update tasks set done = not done where id = ${id} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const addHabit = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((name: string) => str.min(1).max(80).parse(name))
  .handler(async ({ context, data: name }) => {
    const sql = await getSql();
    await sql`insert into habits (user_id, name) values (${context.userId}, ${name})`;
    return { ok: true };
  });

export const toggleHabit = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: number) => z.number().parse(id))
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    await sql`update habits set done_today = not done_today,
      streak = case when done_today then greatest(streak - 1, 0) else streak + 1 end
      where id = ${id} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const addExam = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { title: string; exam_date: string }) =>
    z.object({ title: str.min(1), exam_date: str.min(4) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into exam_dates (user_id, title, exam_date) values (${context.userId}, ${data.title}, ${data.exam_date})`;
    return { ok: true };
  });

export const addWeekSlot = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { day: number; label: string; minutes: number }) =>
    z.object({ day: z.number().min(0).max(6), label: str.min(1), minutes: z.number().min(5).max(300) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into week_slots (user_id, day, label, minutes) values (${context.userId}, ${data.day}, ${data.label}, ${data.minutes})`;
    return { ok: true };
  });

export const logStudy = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((minutes: number) => z.number().min(1).max(300).parse(minutes))
  .handler(async ({ context, data: minutes }) => {
    const sql = await getSql();
    await sql`insert into study_logs (user_id, minutes) values (${context.userId}, ${minutes})`;
    await sql`update profiles set weekly_minutes = weekly_minutes + ${minutes},
      last_study_date = current_date,
      streak = case when last_study_date = current_date - 1 then streak + 1
                    when last_study_date = current_date then streak
                    else 1 end,
      points = points + ${minutes},
      goal_percent = least(100, goal_percent + ${Math.min(12, minutes)})
      where user_id = ${context.userId}`;
    return { ok: true };
  });

export const addFlashcards = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((cards: { front: string; back: string }[]) =>
    z.array(z.object({ front: str.min(1), back: str.min(1) })).min(1).max(40).parse(cards),
  )
  .handler(async ({ context, data: cards }) => {
    const sql = await getSql();
    for (const c of cards) {
      await sql`insert into flashcards (user_id, front, back) values (${context.userId}, ${c.front}, ${c.back})`;
    }
    await bumpPoints(context.userId, 15);
    return { ok: true };
  });

export const markFlash = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: number; known: boolean }) => z.object({ id: z.number(), known: z.boolean() }).parse(d))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update flashcards set known = ${data.known} where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true };
  });

export const saveQuiz = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { title: string; questions: unknown }) =>
    z.object({ title: str.min(1), questions: z.any() }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const json = JSON.stringify(data.questions);
    const rows = await sql<{ id: number }>`
      insert into quizzes (user_id, title, questions) values (${context.userId}, ${data.title}, ${json}::jsonb)
      returning id`;
    await bumpPoints(context.userId, 20);
    return rows[0];
  });

export const addMistake = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { subject: string; question: string; wrong: string; correct: string }) =>
    z.object({
      subject: str.max(80),
      question: str.min(1),
      wrong: str.max(400),
      correct: str.max(400),
    }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into mistakes (user_id, subject, question, wrong, correct)
      values (${context.userId}, ${data.subject}, ${data.question}, ${data.wrong}, ${data.correct})`;
    return { ok: true };
  });

export const addTerm = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { term: string; definition: string; subject: string }) =>
    z.object({ term: str.min(1), definition: str.min(1), subject: str.max(80) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into dictionary_terms (user_id, term, definition, subject)
      values (${context.userId}, ${data.term}, ${data.definition}, ${data.subject})`;
    return { ok: true };
  });

export const saveAiNote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { tool: string; title: string; content: string }) =>
    z.object({ tool: str, title: str, content: str.max(30000) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`insert into ai_notes (user_id, tool, title, content)
      values (${context.userId}, ${data.tool}, ${data.title}, ${data.content})`;
    return { ok: true };
  });

function code() {
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}

export const createGroup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { name: string; subject: string; display_name: string }) =>
    z.object({ name: str.min(1), subject: str.max(80), display_name: str.max(80) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const join = code();
    const rows = await sql<{ id: number; join_code: string }>`
      insert into study_groups (owner_id, name, subject, join_code)
      values (${context.userId}, ${data.name}, ${data.subject}, ${join})
      returning id, join_code`;
    const g = rows[0];
    await sql`insert into group_members (group_id, user_id, member_role, display_name)
      values (${g.id}, ${context.userId}, 'teacher', ${data.display_name})`;
    return g;
  });

export const joinGroup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { code: string; display_name: string }) =>
    z.object({ code: str.min(4).max(12), display_name: str.max(80) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const found = await sql<{ id: number }>`select id from study_groups where join_code = ${data.code.toUpperCase()}`;
    if (!found[0]) return { ok: false as const, error: "الكود غير صحيح" };
    await sql`insert into group_members (group_id, user_id, member_role, display_name)
      values (${found[0].id}, ${context.userId}, 'student', ${data.display_name})
      on conflict do nothing`;
    return { ok: true as const };
  });

export const listGroupFeed = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((groupId: number) => z.number().parse(groupId))
  .handler(async ({ context, data: groupId }) => {
    const sql = await getSql();
    const mem = await sql<{ member_role: string }>`
      select member_role from group_members where group_id = ${groupId} and user_id = ${context.userId}`;
    if (!mem[0]) return { posts: [], members: [], allowed: false };
    const posts = await sql<{
      id: number; kind: string; title: string; body: string; due_date: string | null; created_at: string; display_name: string;
    }>`select p.id, p.kind, p.title, p.body, p.due_date, p.created_at, coalesce(m.display_name, '') as display_name
       from group_posts p
       left join group_members m on m.group_id = p.group_id and m.user_id = p.user_id
       where p.group_id = ${groupId} order by p.id desc`;
    const members = await sql<{ user_id: string; member_role: string; display_name: string }>`
      select user_id, member_role, display_name from group_members where group_id = ${groupId}`;
    return { posts, members, allowed: true, role: mem[0].member_role };
  });

export const addGroupPost = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { groupId: number; kind: string; title: string; body: string; due_date?: string | null }) =>
    z.object({
      groupId: z.number(),
      kind: z.enum(["announcement", "assignment"]),
      title: str.max(160),
      body: str.min(1).max(4000),
      due_date: z.string().nullable().optional(),
    }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const mem = await sql<{ member_role: string }>`
      select member_role from group_members where group_id = ${data.groupId} and user_id = ${context.userId}`;
    if (!mem[0] || mem[0].member_role !== "teacher") return { ok: false };
    await sql`insert into group_posts (group_id, user_id, kind, title, body, due_date)
      values (${data.groupId}, ${context.userId}, ${data.kind}, ${data.title}, ${data.body}, ${data.due_date ?? null})`;
    return { ok: true };
  });

async function bumpPoints(userId: string, n: number) {
  const sql = await getSql();
  await sql`update profiles set points = points + ${n}, goal_percent = least(100, goal_percent + 2)
    where user_id = ${userId}`;
}

const AI_PROMPTS: Record<string, string> = {
  transcribe: "أنت مساعد دراسي عربي. فرّغ الدرس التالي إلى عناوين واضحة ونقاط مرتبة بالعربية الفصحى المبسطة.",
  "explain-pdf": "اشرح المقطع الدراسي التالي لطالب ثانوي بالعربية، مع أمثلة قصيرة.",
  explain: "اشرح المفهوم التالي ببساطة ثم بتوسع ثم بلخص ثلاث نقاط.",
  summarize: "لخّص النص في نقاط مرقمة ثم فقرة قصيرة للمراجعة السريعة.",
  booklet: "حوّل النص إلى ملزمة مراجعة: تعريفات، قوانين، أمثلة، أسئلة متوقعة.",
  mindmap: "أنشئ خريطة ذهنية نصية بشكل شجرة باستخدام مسافات وشرطات من النص.",
  "audio-sum": "اكتب ملخصاً صوتياً قصيراً يُقرأ بصوت عالٍ، فقرات قصيرة جداً.",
  irab: "أعرب الجمل التالية إعراباً تفصيلياً بالعربية.",
  lock: "حوّل المعلومة إلى بطاقة تثبيت: الفكرة، سبب أهميتها، تشبيه، سؤال اختبار ذاتي.",
  expected: "اقترح 8 أسئلة متوقعة مع إجابات موجزة من الدرس.",
  "teacher-sim": "قم بدور مدرس صارم ولطيف: اطرح 5 أسئلة متدرجة وانتظر كأنك تحاور الطالب، واكتب الإجابات النموذجية في النهاية.",
  "grade-me": "صحّح إجابة الطالب التالية. النص يحتوي السؤال ثم الإجابة. أعطِ الدرجة من 10 وملاحظات.",
  "daily-challenge": "أنشئ تحدي اليوم: سؤال واحد متوسط الصعوبة مع أربع خيارات والإجابة الصحيحة والشرح. المادة أو النص مرفق.",
  "exam-night": "ضع خطة ليلة الامتحان على 4 ساعات من المادة المرفقة، مع فواصل.",
  oral: "أسئلة شفهية قصيرة (8 أسئلة) مع إجابات نموذجية من سطر واحد.",
  "common-mistakes": "اذكر الأخطاء الشائعة في هذا الدرس وكيف تتجنبها.",
  extract: "استخرج القوانين، التعريفات، التواريخ، والأسماء من النص في جداول نصية.",
  timebox: "الطالب يملك وقتاً محدوداً مذكوراً في النص. ضع خطة دقيقة بالدقائق.",
  compress: "اختصر الدرس إلى صفحة واحدة كثيفة بدون فقدان القوانين الأساسية.",
  "photo-explain": "اشرح محتوى الدرس/الوصف المرفق كأنك ترى الصفحة.",
};

export const runAi = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { tool: string; input: string }) =>
    z.object({ tool: str, input: str.min(1).max(12000) }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "الذكاء الاصطناعي غير متاح حالياً" };
    const system = AI_PROMPTS[data.tool] ?? "أنت مساعد دراسي عربي دقيق ومباشر.";
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 900,
        messages: [
          { role: "system", content: system },
          { role: "user", content: data.input },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: "تعذر توليد الإجابة الآن" };
    const body = (await res.json()) as { choices: { message: { content: string } }[] };
    const text = body.choices[0]?.message.content ?? "";
    const sql = await getSql();
    await sql`insert into ai_notes (user_id, tool, title, content)
      values (${context.userId}, ${data.tool}, ${data.tool}, ${text})`;
    await bumpPoints(context.userId, 6);
    return { ok: true as const, text };
  });

export const runAiJson = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { kind: "flash" | "quiz"; input: string; count?: number }) =>
    z.object({ kind: z.enum(["flash", "quiz"]), input: str.min(1).max(12000), count: z.number().optional() }).parse(d),
  )
  .handler(async ({ context, data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "الذكاء الاصطناعي غير متاح حالياً" };
    const n = data.count ?? 8;
    const prompt =
      data.kind === "flash"
        ? `أنشئ ${n} بطاقات فلاش من النص. أعد JSON فقط: [{"front":"...","back":"..."}] بالعربية.`
        : `أنشئ ${n} أسئلة اختيار من متعدد. JSON فقط: [{"q":"...","options":["أ","ب","ج","د"],"answer":0,"why":"..."}] بالعربية. answer رقم الخيار الصحيح من 0.`;
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 1200,
        messages: [
          { role: "system", content: prompt },
          { role: "user", content: data.input },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: "تعذر التوليد" };
    const body = (await res.json()) as { choices: { message: { content: string } }[] };
    const raw = body.choices[0]?.message.content ?? "[]";
    const match = raw.match(/\[[\s\S]*\]/);
    try {
      const parsed = JSON.parse(match?.[0] ?? raw);
      if (data.kind === "flash") {
        const cards = z.array(z.object({ front: str, back: str })).parse(parsed);
        const sql = await getSql();
        for (const c of cards) {
          await sql`insert into flashcards (user_id, front, back) values (${context.userId}, ${c.front}, ${c.back})`;
        }
        await bumpPoints(context.userId, 15);
        return { ok: true as const, cards };
      }
      const questions = z
        .array(z.object({ q: str, options: z.array(str).min(2), answer: z.number(), why: str.optional() }))
        .parse(parsed);
      const sql = await getSql();
      await sql`insert into quizzes (user_id, title, questions)
        values (${context.userId}, ${"اختبار"}, ${JSON.stringify(questions)}::jsonb)`;
      await bumpPoints(context.userId, 20);
      return { ok: true as const, questions };
    } catch {
      return { ok: false as const, error: "صيغة غير متوقعة من النموذج" };
    }
  });

export const speakSummary = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((text: string) => str.min(1).max(2500).parse(text))
  .handler(async ({ data: text }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "الصوت غير متاح" };
    const res = await fetch("https://api.x.ai/v1/tts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ text: text.slice(0, 1200), voice_id: "eve" }),
    });
    if (!res.ok) return { ok: false as const, error: "تعذر توليد الصوت" };
    const buf = Buffer.from(await res.arrayBuffer());
    return { ok: true as const, audio: buf.toString("base64") };
  });
