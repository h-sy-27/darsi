import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { DarsiBoot } from "@/lib/darsi-types";
import { getBootstrap } from "@/lib/server/darsi";

const Ctx = createContext<{
  data: DarsiBoot | null;
  loading: boolean;
  error: string | null;
  reload: () => void;
}>({ data: null, loading: true, error: null, reload: () => {} });

export function DarsiProvider({ children, enabled }: { children: React.ReactNode; enabled: boolean }) {
  const [data, setData] = useState<DarsiBoot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(() => {
    if (!enabled) {
      setLoading(false);
      return;
    }
    setLoading(true);
    getBootstrap()
      .then((d) => {
        setData(d);
        setError(null);
      })
      .catch((e: unknown) => {
        setError(e instanceof Error ? e.message : "خطأ");
      })
      .finally(() => setLoading(false));
  }, [enabled]);

  useEffect(() => {
    reload();
  }, [reload]);

  return <Ctx.Provider value={{ data, loading, error, reload }}>{children}</Ctx.Provider>;
}

export function useDarsi() {
  return useContext(Ctx);
}
