export type ToolGroup =
  | "understand"
  | "memory"
  | "exam"
  | "extract"
  | "organize"
  | "extra";

export type ToolDef = {
  id: string;
  title: string;
  blurb: string;
  group: ToolGroup;
  mode: "ai" | "flash" | "quiz" | "cover" | "timer" | "tasks" | "habits" | "exams" | "week" | "calc" | "scan" | "mistakes" | "dict" | "today";
};

export const GROUPS: { id: ToolGroup; title: string }[] = [
  { id: "understand", title: "الفهم والشرح" },
  { id: "memory", title: "الحفظ والتثبيت" },
  { id: "exam", title: "الامتحانات والتقييم" },
  { id: "extract", title: "الاستخراج والمعرفة" },
  { id: "organize", title: "التنظيم والتحفيز" },
  { id: "extra", title: "أدوات مساعدة" },
];

export const TOOLS: ToolDef[] = [
  { id: "transcribe", title: "فرّغ الدرس", blurb: "حوّل نص الدرس إلى تفريغ منظم بعناوين.", group: "understand", mode: "ai" },
  { id: "explain-pdf", title: "حدّد واشرح", blurb: "الصق مقطعاً من الكتاب واطلب شرحاً واضحاً.", group: "understand", mode: "ai" },
  { id: "photo-explain", title: "صوّر واشرح", blurb: "صف ما في الصورة أو الصق النص المستخرج.", group: "understand", mode: "scan" },
  { id: "explain", title: "اشرح لي", blurb: "شرح مبسّط لأي مفهوم صعب.", group: "understand", mode: "ai" },
  { id: "summarize", title: "تلخيص", blurb: "ملخص مركز بالنقاط الأساسية.", group: "understand", mode: "ai" },
  { id: "booklet", title: "حوّلها لملزمة", blurb: "ملزمة جاهزة للمراجعة قبل الامتحان.", group: "understand", mode: "ai" },
  { id: "mindmap", title: "خريطة ذهنية", blurb: "شجرة مفاهيم من الدرس.", group: "memory", mode: "ai" },
  { id: "flashcards", title: "فلاش كاردز", blurb: "بطاقات سؤال وجواب للحفظ.", group: "memory", mode: "flash" },
  { id: "audio-sum", title: "ملخص صوتي", blurb: "استمع للملخص بصوت واضح.", group: "memory", mode: "ai" },
  { id: "irab", title: "إعراب الجمل", blurb: "إعراب دقيق للجملة أو الفقرة.", group: "memory", mode: "ai" },
  { id: "vocab", title: "كلماتي", blurb: "بنك مفردات المادة.", group: "memory", mode: "dict" },
  { id: "cover", title: "غطّي وافتكر", blurb: "اخفِ الإجابة واختبر نفسك.", group: "memory", mode: "cover" },
  { id: "lock", title: "تثبيت المعلومة", blurb: "تكرار متباعد للفكرة حتى تثبت.", group: "memory", mode: "ai" },
  { id: "quiz", title: "اختبار تفاعلي", blurb: "أسئلة اختيار من متعدد فورية.", group: "exam", mode: "quiz" },
  { id: "full-exam", title: "امتحان كامل", blurb: "نموذج امتحان بعدة أسئلة.", group: "exam", mode: "quiz" },
  { id: "expected", title: "الأسئلة المتوقعة", blurb: "أسئلة محتملة حسب الدرس.", group: "exam", mode: "ai" },
  { id: "teacher-sim", title: "محاكاة المدرس", blurb: "يسألك المدرس الافتراضي ويتابعك.", group: "exam", mode: "ai" },
  { id: "grade-me", title: "حلّل إجابتي", blurb: "تصحيح وتغذية راجعة على إجابتك.", group: "exam", mode: "ai" },
  { id: "daily-challenge", title: "تحدي اليوم", blurb: "سؤال يومي يكسبك نقاطاً.", group: "exam", mode: "ai" },
  { id: "exam-night", title: "ليلة الامتحان", blurb: "خطة مراجعة مكثفة لآخر ليلة.", group: "exam", mode: "ai" },
  { id: "oral", title: "اسألني شفوي", blurb: "أسئلة شفهية قصيرة.", group: "exam", mode: "ai" },
  { id: "common-mistakes", title: "أخطاء شائعة", blurb: "أخطاء يقع فيها الطلاب في هذا الدرس.", group: "exam", mode: "ai" },
  { id: "mistake-book", title: "دفتر أخطائي", blurb: "سجّل أخطاءك وابنِ اختباراً منها.", group: "exam", mode: "mistakes" },
  { id: "extract", title: "استخرج من الدرس", blurb: "قوانين، تواريخ، تعريفات.", group: "extract", mode: "ai" },
  { id: "dict", title: "قاموس المادة", blurb: "مصطلحات وتعريفات محفوظة.", group: "extract", mode: "dict" },
  { id: "today", title: "مراجعة اليوم", blurb: "ماذا تراجع اليوم حسب جدولك.", group: "organize", mode: "today" },
  { id: "timebox", title: "على قد وقتك", blurb: "خطة دراسة تناسب الدقائق المتاحة.", group: "organize", mode: "ai" },
  { id: "schedule", title: "جدول المذاكرة", blurb: "وزّع المواد على أيام الأسبوع.", group: "organize", mode: "week" },
  { id: "countdown", title: "عداد الامتحانات", blurb: "كم بقي على كل امتحان.", group: "organize", mode: "exams" },
  { id: "habits", title: "عاداتي", blurb: "عادات يومية ونقاط الاستمرارية.", group: "organize", mode: "habits" },
  { id: "timer", title: "مؤقت المذاكرة", blurb: "جلسة تركيز مع تسجيل الدقائق.", group: "organize", mode: "timer" },
  { id: "tasks", title: "مهامي", blurb: "قائمة واجباتك.", group: "organize", mode: "tasks" },
  { id: "scanner", title: "الماسح", blurb: "التقط صفحة الدرس واحفظها.", group: "extra", mode: "scan" },
  { id: "calc", title: "الآلة الحاسبة", blurb: "حاسبة علمية مبسطة.", group: "extra", mode: "calc" },
  { id: "compress", title: "ضغط الدرس", blurb: "اختصر الدرس إلى صفحة واحدة.", group: "extra", mode: "ai" },
];

export function toolById(id: string) {
  return TOOLS.find((t) => t.id === id);
}
