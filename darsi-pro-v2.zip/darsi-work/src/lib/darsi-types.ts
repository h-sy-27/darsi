export type Profile = {
  user_id: string;
  display_name: string;
  role: string;
  grade: string;
  points: number;
  streak: number;
  last_study_date: string | null;
  goal_percent: number;
  weekly_minutes: number;
  onboarded: boolean;
};

export type QuizQ = { q: string; options: string[]; answer: number; why?: string };

export type DarsiBoot = {
  profile: Profile;
  subjects: { id: number; name: string; grade: string }[];
  materials: { id: number; subject_id: number | null; title: string; kind: string; body: string }[];
  tasks: { id: number; title: string; due_date: string | null; done: boolean }[];
  habits: { id: number; name: string; done_today: boolean; streak: number }[];
  exams: { id: number; title: string; exam_date: string }[];
  week: { id: number; day: number; label: string; minutes: number }[];
  mistakes: { id: number; subject: string; question: string; wrong: string; correct: string }[];
  flash: { id: number; front: string; back: string; known: boolean }[];
  dict: { id: number; term: string; definition: string; subject: string }[];
  notes: { id: number; tool: string; title: string; content: string }[];
  quizzes: { id: number; title: string; questions: QuizQ[] }[];
  groups: {
    id: number;
    name: string;
    subject: string;
    join_code: string;
    owner_id: string;
    member_role: string;
  }[];
  logs: { minutes: number; day: string }[];
};
